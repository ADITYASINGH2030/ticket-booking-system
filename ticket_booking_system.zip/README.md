# Ticket Booking System - Starter Project

This archive contains a ready-to-run skeleton for the Ticket Booking System
described in the assignment. It includes a Node.js/Express backend (Postgres)
and a minimal React + TypeScript frontend skeleton.

## Contents
- backend/: Node.js backend (Express) with booking transaction logic
- frontend/: React + TypeScript skeleton (minimal)
- docker-compose.yml : local development with Postgres + backend
- schema.sql : Postgres schema for shows, seats, bookings
- concurrency_test.js : simple script to stress test bookings

## Quickstart (local with Docker)
1. Ensure Docker & Docker Compose are installed.
2. From this archive extract or `cd` into the `backend` folder and run:
   - `docker-compose up --build` (the docker-compose file at repo root starts Postgres + backend)
3. Initialize DB schema:
   - Connect to Postgres (host:localhost port:5432 user:postgres password:password db:tickets)
   - Run `psql` and execute `schema.sql` or use `psql -f schema.sql`.
4. Start frontend separately (if desired) with `npm install` and `npm start` in the frontend folder.

See `backend/README.md` and `frontend/README.md` for more details.
