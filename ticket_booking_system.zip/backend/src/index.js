const express = require('express');
const app = express();
app.use(express.json());

const shows = require('./routes/shows');
const bookings = require('./routes/bookings');

app.use('/api/shows', shows);
app.use('/api/bookings', bookings);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend listening on ${PORT}`));
