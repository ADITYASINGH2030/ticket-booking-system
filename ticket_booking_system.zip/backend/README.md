# Backend - Ticket Booking System

## Setup (local)
1. Ensure Postgres is running (see docker-compose.yml).
2. Run `npm install` in the backend folder (if running locally without Docker).
3. Apply `schema.sql` to the database.
4. Start server: `npm run dev` (development) or `npm start` (production).

## Environment
- DATABASE_URL : Postgres connection string (default used in docker-compose)

## Notes
- Booking logic uses a `SELECT ... FOR UPDATE` inside a transaction to lock seat rows
  and prevent concurrent double-booking.
- Expiry job is included in `src/jobs/expiryJob.js`.
